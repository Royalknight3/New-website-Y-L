
export default function App(){
  return <div className='p-10 text-2xl'>Frontend OK — 卡片风界面可自行扩展</div>
}
